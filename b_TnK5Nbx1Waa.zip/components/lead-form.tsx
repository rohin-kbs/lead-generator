"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Spinner } from "@/components/ui/spinner"
import { Search, Users, Globe, Zap, CheckCircle2, AlertCircle } from "lucide-react"
import { LeadsTable, type Lead } from "@/components/leads-table"

const countries = [
  { value: "US", label: "United States" },
  { value: "UK", label: "United Kingdom" },
  { value: "CA", label: "Canada" },
  { value: "AU", label: "Australia" },
  { value: "DE", label: "Germany" },
  { value: "FR", label: "France" },
  { value: "IN", label: "India" },
  { value: "SG", label: "Singapore" },
  { value: "NL", label: "Netherlands" },
  { value: "SE", label: "Sweden" },
  { value: "CH", label: "Switzerland" },
  { value: "JP", label: "Japan" },
  { value: "BR", label: "Brazil" },
  { value: "MX", label: "Mexico" },
  { value: "ES", label: "Spain" },
  { value: "IT", label: "Italy" },
  { value: "AE", label: "United Arab Emirates" },
  { value: "IE", label: "Ireland" },
]

type FormStatus = "idle" | "loading" | "success" | "error"

export function LeadForm() {
  const [jobTitle, setJobTitle] = useState("")
  const [country, setCountry] = useState("")
  const [numberOfLeads, setNumberOfLeads] = useState("10")
  const [status, setStatus] = useState<FormStatus>("idle")
  const [errorMessage, setErrorMessage] = useState("")
  const [leads, setLeads] = useState<Lead[]>([])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!jobTitle.trim() || !country || !numberOfLeads) {
      setErrorMessage("Please fill in all fields")
      setStatus("error")
      return
    }

    const leadsCount = parseInt(numberOfLeads, 10)
    if (isNaN(leadsCount) || leadsCount < 1 || leadsCount > 500) {
      setErrorMessage("Number of leads must be between 1 and 500")
      setStatus("error")
      return
    }

    setStatus("loading")
    setErrorMessage("")
    setLeads([])

    try {
      const n8nWebhookUrl = process.env.NEXT_PUBLIC_N8N_WEBHOOK_URL || "YOUR_N8N_WEBHOOK_URL"
      
      const response = await fetch(n8nWebhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jobTitle: jobTitle.trim(),
          country: country,
          numberOfLeads: parseInt(numberOfLeads, 10),
          timestamp: new Date().toISOString(),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to submit lead request")
      }

      // Parse the response from n8n (expecting an array of leads)
      const data = await response.json()
      
      // Map the response to our Lead interface
      // Adjust these field mappings based on your actual Theirstack API response
      const mappedLeads: Lead[] = Array.isArray(data) 
        ? data.map((item: Record<string, unknown>) => ({
            companyName: (item.company_name || item.companyName || item.name || "N/A") as string,
            domain: (item.domain || item.website || "N/A") as string,
            location: (item.location || item.country || item.headquarters || "N/A") as string,
            employeeCount: (item.employee_count || item.employeeCount || item.employees || "N/A") as number | string,
            industryType: (item.industry || item.industryType || item.sector || "N/A") as string,
            apolloUrl: item.apollo_url as string | undefined,
          }))
        : []

      setLeads(mappedLeads)
      setStatus("success")
      
    } catch (error) {
      console.error("Error submitting to n8n:", error)
      setErrorMessage("Failed to process your request. Please try again.")
      setStatus("error")
    }
  }

  const handleReset = () => {
    setJobTitle("")
    setCountry("")
    setNumberOfLeads("10")
    setLeads([])
    setStatus("idle")
    setErrorMessage("")
  }

  return (
    <div className="space-y-8">
      <Card className="w-full border-border/50 bg-card/50 backdrop-blur-sm">
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="jobTitle" className="text-sm font-medium text-foreground">
                Job Title
              </Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="jobTitle"
                  type="text"
                  placeholder="e.g. Software Engineer, Marketing Manager"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="pl-10 bg-input border-border focus:border-primary focus:ring-primary"
                  disabled={status === "loading"}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="country" className="text-sm font-medium text-foreground">
                Country
              </Label>
              <Select value={country} onValueChange={setCountry} disabled={status === "loading"}>
                <SelectTrigger id="country" className="bg-input border-border focus:border-primary focus:ring-primary">
                  <Globe className="mr-2 h-4 w-4 text-muted-foreground" />
                  <SelectValue placeholder="Select a country" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {countries.map((c) => (
                    <SelectItem key={c.value} value={c.value}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="numberOfLeads" className="text-sm font-medium text-foreground">
                Number of Leads
              </Label>
              <div className="relative">
                <Users className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="numberOfLeads"
                  type="number"
                  min="1"
                  max="500"
                  placeholder="e.g. 10, 50, 100"
                  value={numberOfLeads}
                  onChange={(e) => setNumberOfLeads(e.target.value)}
                  className="pl-10 bg-input border-border focus:border-primary focus:ring-primary"
                  disabled={status === "loading"}
                />
              </div>
              <p className="text-xs text-muted-foreground">Enter a number between 1 and 500</p>
            </div>

            {status === "error" && errorMessage && (
              <div className="flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
                <AlertCircle className="h-4 w-4" />
                {errorMessage}
              </div>
            )}

            {status === "success" && leads.length > 0 && (
              <div className="flex items-center gap-2 rounded-lg bg-primary/10 p-3 text-sm text-primary">
                <CheckCircle2 className="h-4 w-4" />
                Found {leads.length} leads successfully!
              </div>
            )}

            <div className="flex gap-3">
              <Button 
                type="submit" 
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 transition-all"
                disabled={status === "loading"}
              >
                {status === "loading" ? (
                  <>
                    <Spinner className="mr-2 h-4 w-4" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-4 w-4" />
                    Generate Leads
                  </>
                )}
              </Button>
              
              {leads.length > 0 && (
                <Button 
                  type="button"
                  variant="outline"
                  onClick={handleReset}
                  className="border-border hover:bg-muted"
                >
                  Reset
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      <LeadsTable leads={leads} />
    </div>
  )
}
