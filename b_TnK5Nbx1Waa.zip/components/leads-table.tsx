"use client"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Building2, Globe, MapPin, Users, Briefcase } from "lucide-react"

export interface Lead {
  companyName: string
  domain: string
  location: string
  employeeCount: number | string
  industryType: string
  apolloUrl?: string
}

interface LeadsTableProps {
  leads: Lead[]
}

export function LeadsTable({ leads }: LeadsTableProps) {
  if (leads.length === 0) {
    return null
  }

  const getApolloSearchUrl = (companyName: string, domain: string) => {
    // Generate Apollo search URL based on company name and domain
    const searchQuery = encodeURIComponent(companyName)
    return `https://app.apollo.io/#/companies?qKeywords=${searchQuery}&sortAscending=false&sortByField=account_last_activity_date`
  }

  return (
    <Card className="w-full border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl">
          <Building2 className="h-5 w-5 text-primary" />
          Generated Leads ({leads.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    Company Name
                  </div>
                </TableHead>
                <TableHead className="text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    Domain
                  </div>
                </TableHead>
                <TableHead className="text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    Location
                  </div>
                </TableHead>
                <TableHead className="text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Employees
                  </div>
                </TableHead>
                <TableHead className="text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4" />
                    Industry
                  </div>
                </TableHead>
                <TableHead className="text-muted-foreground text-right">
                  Apollo
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leads.map((lead, index) => (
                <TableRow key={index} className="border-border hover:bg-muted/50">
                  <TableCell className="font-medium text-foreground">
                    {lead.companyName}
                  </TableCell>
                  <TableCell>
                    <a
                      href={`https://${lead.domain}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      {lead.domain}
                    </a>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {lead.location}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {typeof lead.employeeCount === "number"
                      ? lead.employeeCount.toLocaleString()
                      : lead.employeeCount}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {lead.industryType}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                      className="border-primary/50 text-primary hover:bg-primary/10"
                    >
                      <a
                        href={lead.apolloUrl || getApolloSearchUrl(lead.companyName, lead.domain)}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="mr-1 h-3 w-3" />
                        View
                      </a>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
